me = {
"first": "Daniel",
        "last": "Avilez",
        "age": 27,
        "hobbies": [],
        "address": {
            "street": "dark",
            "number": "802",
            "city": "Tucson",
            "state": "Arizona",
            "zip": "85756"
        }

}        