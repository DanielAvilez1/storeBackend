# put data here to use as test data, while database connection is set up

mock_data = [
    {
        "id": 1,
        "price": 299.99,
        "stock": 1,
        "title": 'Jordan 11',
        "image": "spacejam.webp",
        "catagory": "Jordans"
    },
    {
        "id": 2,
        "price": 399.50,
        "stock": 1,
        "title": 'Jordan 1',
        "image": "blacktoe.jpeg",
        "catagory": "Jordans"
    },
    {
        "id": 3,
        "price": 599.99,
        "stock": 1,
        "title": "Jordan 4",
        "image": "bred.jpeg",
        "catagory": "Jordans",
    },
    {
        "id": 4,
        "price": 199.99,
        "stock": 1,
        "title": "Air Max",
        "image": "air.jpeg",
        "catagory": "Nike",
    },
    {
        "id": 5,
        "price": 99.50,
        "stock": 1,
        "title": "Yeezy 380",
        "image": "380.jpeg",
        "catagory": "Yeezy",
    },


]
